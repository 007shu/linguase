package com.example.myapplicationapp;

public class QuizQuestion {
    public QuizQuestion(String question, String option, String option1, String option2, String option3, String correctAnswer) {
    }

    public int getOption1() {
        return 0;
    }

    public int getOption2() {
        return 0;
    }

    public int getQuestion() {
        return 0;
    }

    public int getOption3() {
        return 0;
    }

    public int getOption4() {
        return 0;
    }
}
