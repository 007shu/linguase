package com.example.myapplicationapp;

public class Interpreter {
    public void run(float[][] input, float[][] output) {
    }

    public void close() {

    }
}

