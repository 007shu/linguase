package com.example.myapplicationapp;

import org.vosk.android.RecognitionListener;

public class SpeechServiceListener implements RecognitionListener {
    @Override
    public void onPartialResult(String hypothesis) {

    }

    @Override
    public void onResult(String hypothesis) {

    }

    @Override
    public void onFinalResult(String hypothesis) {

    }

    @Override
    public void onError(Exception exception) {

    }

    @Override
    public void onTimeout() {

    }
}
